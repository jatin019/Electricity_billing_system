package billing.entities;

public class Customer {
    private int id;
    private String name;
    private String address;
    private int meterNumber;
    private int unitsConsumed;
    private double totalFare;

    // Constructor accepting name, address, and meterNumber
    public Customer(int id, String name, String address, int meterNumber, int unitsConsumed, double totalFare) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.meterNumber = meterNumber;
        this.unitsConsumed = unitsConsumed;
        this.totalFare = totalFare;
    }

     public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getMeterNumber() {
        return meterNumber;
    }

    public void setMeterNumber(int meterNumber) {
        this.meterNumber = meterNumber;
    }

    public int getUnitsConsumed() {
        return unitsConsumed;
    }

    public void setUnitsConsumed(int unitsConsumed) {
        this.unitsConsumed = unitsConsumed;
    }

  
    public double getTotalFare() {
        return totalFare;
    }

    public void setTotalFare(double totalFare) {
        this.totalFare = totalFare;
    }

}



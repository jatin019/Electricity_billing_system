package billing.actions;

import billing.database.DatabaseConnector;
import billing.entities.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddCustomer {
    private static boolean containsText(String input) {
        return input.matches("[a-zA-Z ]+");
    }
    public static void addCustomer(Customer customer) {
        
        try {
            double unitCharge = 8.0; // Cost per unit

            double totalFare = customer.getUnitsConsumed() * unitCharge;

            if (!containsText(customer.getName()) || !containsText(customer.getAddress())) {
                throw new IllegalArgumentException("Error: Name or Address cannot be numbers.");  }

            Connection conn = DatabaseConnector.getConnection();
            String sql = "INSERT INTO customers (name, address, meter_number, units_consumed, total_fare) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, customer.getName());
            pstmt.setString(2, customer.getAddress());
            pstmt.setInt(3, customer.getMeterNumber());
            pstmt.setInt(4, customer.getUnitsConsumed());
            pstmt.setDouble(5, totalFare);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Customer added successfully!");
            } else {
                System.out.println("Failed to add customer.");
            }
            pstmt.close();
            conn.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}


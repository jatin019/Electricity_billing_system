package billing.actions;

import billing.entities.Customer;

import java.util.Scanner;

public class ElectricityBillingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int choice;
        do {
            System.out.println("Electricity Billing System Menu:");
            System.out.println("1. Add a new customer");
            System.out.println("2. View customer details");
            System.out.println("3. Update customer details");
            System.out.println("4. Delete a customer");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 
            switch (choice) {
                case 1:
                    addNewCustomer(scanner);
                    break;
                case 2:
                    viewCustomerDetails();
                    break;
                case 3:
                    updateCustomerDetails(scanner);
                    break;
                case 4:
                    deleteCustomer(scanner);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice!");
                    break;
            }
        } while (choice != 5);

        scanner.close();
    }

    private static void addNewCustomer(Scanner scanner) {
        System.out.println("Enter customer ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.println("Enter customer address: ");
        String address = scanner.nextLine();
        System.out.println("Enter meter number: ");
        int meterNumber = scanner.nextInt();
        scanner.nextLine(); 
        System.out.println("Enter units consumed: ");
        int unitsConsumed = scanner.nextInt();
        scanner.nextLine();

        Customer newCustomer = new Customer(id, name, address, meterNumber, unitsConsumed, 0);
        AddCustomer.addCustomer(newCustomer);
        
    }

    private static void viewCustomerDetails() {
        ViewCustomer.viewCustomers();
    }

    private static void updateCustomerDetails(Scanner scanner) {
        System.out.println("Enter customer ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 
    
        System.out.println("Enter updated customer name: ");
        String name = scanner.nextLine();
        System.out.println("Enter updated customer address: ");
        String address = scanner.nextLine();
        System.out.println("Enter updated meter number: ");
        int meterNumber = scanner.nextInt();
        scanner.nextLine(); 
    
        System.out.println("Enter updated unit: ");
        int unitsConsumed = scanner.nextInt();
        scanner.nextLine(); 
        
        Customer updatedCustomer = new Customer(id, name, address, meterNumber, unitsConsumed, 0);
        updatedCustomer.setUnitsConsumed(unitsConsumed);
        
        UpdateCustomer.updateCustomer(updatedCustomer);
    }

    private static void deleteCustomer(Scanner scanner) {
        System.out.println("Enter customer ID to delete: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); 

        DeleteCustomer.deleteCustomer(customerId);
        
    }
}

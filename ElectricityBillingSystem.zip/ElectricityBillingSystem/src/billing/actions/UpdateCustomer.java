package billing.actions;

import billing.database.DatabaseConnector;
import billing.entities.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateCustomer {
   public static void updateCustomer(Customer customer) {
        try {
            double unitCharge = 8.0; // Cost per unit
            double totalFare = customer.getUnitsConsumed() * unitCharge;

            Connection conn = DatabaseConnector.getConnection();
            String sql = "UPDATE customers SET name = ?, address = ?, meter_number = ?, units_consumed = ?, total_fare = ? WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, customer.getName());
            pstmt.setString(2, customer.getAddress());
            pstmt.setInt(3, customer.getMeterNumber());
            pstmt.setInt(4, customer.getUnitsConsumed());
            pstmt.setDouble(5, totalFare);
            pstmt.setInt(6, customer.getId());

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Customer details updated successfully!");
            } else {
                System.out.println("Failed to update customer details.");
            }

            pstmt.close();
            conn.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
package billing.actions;

import billing.database.DatabaseConnector;
import billing.entities.Customer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ViewCustomer {
    public static void viewCustomers() {
        try {
            Connection conn = DatabaseConnector.getConnection();
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM customers";
            ResultSet rs = stmt.executeQuery(sql);

            boolean hasCustomers = false;

            System.out.println("---------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("| %-3s | %-20s | %-40s | %-15s | %-15s | %-15s |\n",
                    "ID", "Name", "Address", "Meter Number", "Units Consumed", "Total Fare");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------");
            while (rs.next()) {
                hasCustomers = true;
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String address = rs.getString("address");
                int meterNumber = rs.getInt("meter_number");
                int unitsConsumed = rs.getInt("units_consumed");
                double totalFare = rs.getDouble("total_fare");

                System.out.printf("| %-3d | %-20s | %-40s | %-15d | %-15d | %-15.2f |\n",
                        id, name, address, meterNumber, unitsConsumed, totalFare);
            }
            System.out.println("---------------------------------------------------------------------------------------------------------------------------");

            if (!hasCustomers) {
                System.out.println("No customers found in the database.");
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

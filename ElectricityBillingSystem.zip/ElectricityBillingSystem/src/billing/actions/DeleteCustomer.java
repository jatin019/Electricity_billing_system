package billing.actions;

import billing.database.DatabaseConnector;
import billing.entities.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteCustomer {
    public static void deleteCustomer(int customerId) {
        try {
            Connection conn = DatabaseConnector.getConnection();
            String sql = "DELETE FROM customers WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, customerId);

            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Customer deleted successfully!");
            } 
            else {
                System.out.println("Failed to delete customer.");
            }

            pstmt.close();
            conn.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
